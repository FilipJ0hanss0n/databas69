<header><!--Sidhuvud-->
            <h1>Min onlinebutik - <?php echo $h1span;?></h1>
	</header>