<!DOCTYPE html>
<html lang="sv">
  <head>
     <meta charset="utf-8">
     <title>Produkter</title>
		 <link rel="stylesheet" href="css/stilmall.css">
  </head>
  <body id="produkter">
    <div id="wrapper">
      
	<?php
	  require "masthead.php";
	  require "menu.php";
	?>
		
		
		
		<main> <!--Huvudinnehåll-->
		startsida för min webbutik
		</main>
		
		<?php
		require "footer.php";
		?>

	</div>
  </body>
</html>