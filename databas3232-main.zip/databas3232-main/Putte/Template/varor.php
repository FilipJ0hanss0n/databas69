<?php
	$varor=array(
	array("äpple)
	
?>