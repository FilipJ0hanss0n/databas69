<?php
	
	$h1span = "varor";
	
	header("Content-type:text/html; charset=utf-8");
	require "../Template/sida3-template.php";
?>