<?php
	
	$h1span = "login";
	
	header("Content-type:text/html; charset=utf-8");
	require "../Template/login-template.php";
	
?>