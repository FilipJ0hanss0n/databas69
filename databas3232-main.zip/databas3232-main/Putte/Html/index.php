<?php
	
	$h1span = "start";
	
	header("Content-type:text/html; charset=utf-8");
	require "../Template/index-template.php";
?>