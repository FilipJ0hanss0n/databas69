<?php
  $varor=array(
    array("Äpple","Grönt surt","50", "bilder/apple.jpg"),
    array("Apelsin","Orange söt", "38","bilder/orange.jpg"),
    array("Päron","Gult saftigt", "100","bilder/pear.jpg"),
    array("Banan","Gul böjd", "30","bilder/banana.jpg"),
    array("Grapefrukt","Konstig", "300","bilder/banana.jpg"),
  );
