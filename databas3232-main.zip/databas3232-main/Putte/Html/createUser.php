<?php

	$h1span = "Skapa-User";
	
	header("Content-type:text/html; charset=utf-8");
	require "../Template/createUser-template.php";
	
?>